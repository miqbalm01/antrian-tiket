<script type="text/javascript" src="<?= base_url("asset/js"); ?>/jquery-3.3.1.js"></script>
<script type="text/javascript" src="<?= base_url("asset/js"); ?>/bootstrap.js"></script>
<script type="text/javascript" src="<?= base_url("asset/js"); ?>/datatables.min.js"></script>